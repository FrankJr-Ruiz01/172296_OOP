package Deeznut;

	public class ejemplo{
		public static void main(String args[]) {
			Proceso p= new Proceso();
			p.ejecutar();
		}
		 	
}
