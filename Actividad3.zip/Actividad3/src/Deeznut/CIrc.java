package Deeznut;

public class CIrc {
	public int id;
	public float radio;
	
	public CIrc() {
		this(172296,0);
	}
	public CIrc(int id, int i) {
		this.id=id;
		this.radio=id/100;
		
		Cuadrao cuad=new Cuadrao();
		cuad.process(this);
	}

}
