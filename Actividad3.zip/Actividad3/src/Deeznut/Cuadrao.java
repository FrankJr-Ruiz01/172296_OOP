package Deeznut;

public class Cuadrao {
	int x;
	int y;
	
	CIrc cir;
	int id;
	float radio;
	
	public Cuadrao() {
		this(0,0,0);
	}
	public Cuadrao(int id, int x, int y) {
		this.x=x;
		this.y=y;
		this.id=id;
		
	}
	public void process(CIrc cIrc) {
		this.cir= cIrc;
		this.id=191201;
		
	}

}
