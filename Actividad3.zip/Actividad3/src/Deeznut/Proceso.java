package Deeznut;

import java.util.Scanner;

public class Proceso {
	
	public void ejecutar() {
		
		CIrc cir=new CIrc();
		Cuadrao cuad=new Cuadrao();
		
		boolean bool = Boolean.parseBoolean("true");
		int value = 0;
		String val= Integer.toBinaryString(value);
		bool= Boolean.valueOf(val);
		Scanner scan = new Scanner(System.in);
		System.out.println("Ingrese la figura a calcular");
		String unString = scan.nextLine();
		boolean boolEscaneado = Boolean.parseBoolean(unString);
		System.out.println("Esto es lo que ingresaste: " + boolEscaneado);
		
		if(bool==true) {
		System.out.println("Ingresaste circulo");
		System.out.println("Ingrese el radio");
		String unString1 = scan.nextLine();
		float intEscaneado = Float.parseFloat(unString1);
		System.out.println("El radio: " + intEscaneado/100);
		float x=intEscaneado/100;
		System.out.println("La circunferencia es: " + Math.PI*(2*x));
		System.out.println("El area es: " + Math.PI*(x*x));
		}
		else if(bool==false) {
	    System.out.println("Ingresaste cuadrado");	
		System.out.println("Ingrese el lado");
		String unString2 = scan.nextLine();
		float intEscaneado = Float.parseFloat(unString2);
		System.out.println("El lado: " + intEscaneado/100);
		float y=intEscaneado/100;
		System.out.println("La diagonal es: " + Math.sqrt(y*y + y*y));
		System.out.println("El perimetro es: " + y*4);
		System.out.println("El area es: " + y*y);
		}
		scan.close();
		//System.out.println("circulo id: "+ cir.id);
	}


}
